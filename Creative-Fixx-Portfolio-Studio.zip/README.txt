CREATIVE FIXX — SIX DISTINCT PORTFOLIO COMPOSITIONS

Unzip and open index.html to use the builder.

1. Street Poster: split cover and an overlapping poster wall.
2. The Design Journal: magazine masthead and alternating numbered chapters.
3. Sticker Scrapbook: notebook sidebar and taped polaroid cards.
4. Type Manifesto: giant typography and an expandable numbered project index.
5. The Exhibition: identity rail and asymmetric image-first artwork gallery.
6. The Slide Deck: horizontal cover and individual full-size project slides. Use the slide links or scroll sideways.

These have separate website structures and SVG compositions. Each library card offers an SVG, an online starting point, and a ZIP containing the template plus three matching editable assets.

Customization includes fonts, color, size, spacing, corners, borders, headline effects, texture, and movable sticker layers. Column settings apply to poster, scrapbook, and exhibition layouts. Other compositions retain their own structure. Uploaded project images and stories are shared across template changes. Selecting a new style resets its design settings and default sticker arrangement.

The online layout adapts for mobile. SVG exports are fixed page compositions with editable live text and vector groups. They may wrap differently and abbreviate long copy. Uploaded photos stay raster. Website exports preserve full project descriptions.

Vector assets are original simplified motifs inspired by the Creative Fixx brand direction, not extracted versions of the detailed logo or mascot. Fonts are not bundled; web fonts load when online. SVG editors may need substitute fonts.

Drafts save locally when browser storage is available. Export to keep a backup. Accounts, cloud draft storage, and publishing individual portfolios are not included yet.

Verified: JavaScript syntax, runtime composition switching, asset insertion and positioning, SVG export, and XML structure. SVG templates were rendered and visually inspected together. Website browser appearance and pointer interactions remain unverified. Sites publishing remains blocked by the environment approval policy; no live website is claimed.

REFERENCE-INSPIRED EXPANSION
There are now nine templates. New additions:
- Soft Form Studio: Cormorant Garamond + DM Sans; sculptural serif headings, generous space, rounded swatches, curated image strips, and alternating arched project images.
- Shape Playground: Archivo Black + DM Sans; outlined geometric motifs, a split cover, bright tiles, and flexible visual-system details.
- The Editorial Grid: Bebas Neue + DM Sans; condensed headlines, vertical labels, mixed-size editorial panels, and image/type contrast.

Nine new motifs are available in 04 Assets and the matching template kits: arch, oval, botanical branch, petal, orbit, wave, bracket, label, and cross. The full SVG sheet now contains all 21 motifs. All nine templates remain editable online with SVG and HTML export.

Reference images guided the typography proportions, composition and visual direction. Reference logos, photography, and exact commercial fonts are not included or reproduced. Font files are not bundled. Cormorant Garamond is a web-font interpretation of the sculptural serif direction; local SVG previews may use fallback fonts.

Verified: all nine composition switches, project/sticker rendering and export through runtime checks, SVG XML structure, and rendered SVG previews of the three new styles. Live browser verification remains unavailable; hosted publication remains blocked by the existing environment approval policy.
