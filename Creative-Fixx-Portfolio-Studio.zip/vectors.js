/* Editable portfolio layouts: live text and named vector groups. */
(function(root){
const xml=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&apos;'}[c]));
function lines(text,limit=38){return String(text).split('\n').flatMap(line=>{const out=[];let row='';for(const word of line.split(/\s+/)){if(row.length+word.length>limit&&row){out.push(row);row=''}row+=(row?' ':'')+word}out.push(row);return out})}
function makePortfolioVector(data={}){
const layout=data.layout||'grid',accent=/^#[0-9a-f]{6}$/i.test(data.accent||'')?data.accent:'#bb2025';
const projects=data.projects||[{title:'Project one',category:'Brand identity',description:'The brief. Your approach. The result.'},{title:'Project two',category:'Editorial design',description:'Tell the story behind your design.'},{title:'Project three',category:'Packaging',description:'Give your work the space it deserves.'}];
const one=['editorial','bold'].includes(layout),columns=Number(data.columns)|| (one?1:2),gap=Math.max(10,Math.min(65,+data.spacing||28)),w=(1080-(columns-1)*gap)/columns,cardH=(one?682:562)+gap;
const headline=lines(data.headline||'Your work.\nYour rules.',22).slice(0,5),bio=lines(data.bio||'Introduce yourself here. Share what you design, what inspires you, and what makes your work different.',76).slice(0,5);
const start=210+headline.length*85+bio.length*25+100;
const h=start+Math.ceil(projects.length/columns)*cardH+200;
const text=(x,y,s,size=20,fill='#230c0d',font='DM Sans, Arial')=>`<text x="${x}" y="${y}" fill="${fill}" font-family="${font}" font-size="${size}">${xml(s)}</text>`;
let svg=`<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 1200 ${h}" width="1200" height="${h}"><title>${xml(data.name||'Your name')} — Editable Portfolio</title><desc>Editable SVG template. Named groups contain live text and vector shapes. Replace labeled image placeholders with your artwork. Uploaded photos remain raster images.</desc><g id="Background"><rect width="1200" height="${h}" fill="#ebe0bc"/></g><g id="Header">${text(60,65,data.name||'YOUR NAME',24)}${text(950,65,'PORTFOLIO / 01',16)}<path d="M60 95H1140" stroke="#230c0d"/></g><g id="Introduction">${text(60,155,data.role||'Graphic designer',18)}${headline.map((l,i)=>text(60,240+i*85,l,78,accent,'Archivo Black, Impact, sans-serif')).join('')}${bio.map((l,i)=>text(60,250+headline.length*85+i*25,l,20)).join('')}</g><g id="Selected-work-label">${text(60,start-35,'SELECTED WORK',18)}<path d="M60 ${start-20}H1140" stroke="#230c0d"/></g>`;
projects.forEach((p,i)=>{const x=60+(i%columns)*(w+gap),y=start+Math.floor(i/columns)*cardH,imageH=one?480:350;const safeImage=typeof p.image==='string'&&/^data:image\/(png|jpeg|webp|gif|svg\+xml)[;,]/.test(p.image)?p.image:null;
svg+=`<g id="Project-${i+1}"><g id="Artwork-${i+1}"><rect x="${x}" y="${y}" width="${w}" height="${imageH}" fill="${i%2?'#c5ab79':'#a4aa38'}"/>${safeImage?`<image x="${x}" y="${y}" width="${w}" height="${imageH}" preserveAspectRatio="xMidYMid meet" xlink:href="${xml(safeImage)}"/>`:`<rect x="${x+30}" y="${y+30}" width="${w-60}" height="${imageH-60}" fill="none" stroke="#230c0d" stroke-dasharray="8 8"/>${text(x+55,y+imageH/2,'PLACE YOUR ARTWORK HERE',one?28:20)}`}</g><g id="Project-copy-${i+1}">${lines(p.title||'Project title',one?65:30).slice(0,2).map((l,j)=>text(x,y+imageH+38+j*30,l,26)).join('')}${text(x,y+imageH+103,p.category||'Category',15)}${lines(p.description||'The brief. Your approach. The result.',one?90:44).slice(0,3).map((l,j)=>text(x,y+imageH+140+j*23,l,17)).join('')}</g></g>`});
svg+=`<g id="Contact"><path d="M60 ${h-155}H1140" stroke="#230c0d"/>${text(60,h-105,'LET’S MAKE SOMETHING GOOD.',26,accent)}${text(60,h-60,data.email||'you@example.com',20)}${text(800,h-60,data.location||'Your city',18)}</g></svg>`;
if(data.font)svg=svg.replaceAll('Archivo Black, Impact, sans-serif',xml(data.font)+', sans-serif');
if(layout==='minimal')svg=svg.replaceAll('#ebe0bc','#ffffff').replaceAll('font-size="78"','font-size="64"');
if(layout==='editorial')svg=svg.replaceAll('Archivo Black, Impact, sans-serif','Georgia, serif');
if(layout==='dark')svg=svg.replaceAll('#ebe0bc','#111519').replaceAll('#230c0d','#f0f0ed').replaceAll('#a4aa38','#303840').replaceAll('#c5ab79','#41474c');
if(layout==='swiss')svg=svg.replaceAll('#ebe0bc','#fafafa').replace('id="Introduction">','id="Introduction"><path d="M25 130V'+(start-45)+'" stroke="'+accent+'" stroke-width="15"/>');
if(layout==='brutalist')svg=svg.replaceAll('#ebe0bc','#ffffff').replaceAll('stroke="#230c0d"','stroke="#230c0d" stroke-width="5"').replaceAll('DM Sans, Arial','Space Mono, monospace');
if(layout==='playful')svg=svg.replaceAll('#ebe0bc','#fff0dc').replaceAll('<rect x=','<rect rx="30" x=');
if(layout==='bold')svg=svg.replaceAll('#ebe0bc','#0b0b0b').replaceAll('#230c0d','#f3ebd6');
const validColor=c=>/^#[\da-f]{6}$/i.test(c||'');
if(validColor(data.paper))svg=svg.replace(/(<g id="Background"><rect[^>]*fill=")[^"]+/, '$1'+data.paper);
if(validColor(data.ink))svg=svg.replaceAll('fill="#230c0d"','fill="'+data.ink+'"').replaceAll('stroke="#230c0d"','stroke="'+data.ink+'"');
if(data.displaySize)svg=svg.replaceAll('font-size="78"','font-size="'+Math.max(32,Math.min(100,+data.displaySize))+'"');
if(data.outline)svg=svg.replace(/(<g id="Artwork-\d+"><rect )/g,'$1stroke="'+(data.ink||'#0b0b0b')+'" stroke-width="'+(+data.outline||0)+'" ');
if(data.headingStyle==='shadow')svg=svg.replace('<g id="Introduction">','<defs><filter id="ink-shadow" x="-10%" y="-10%" width="130%" height="130%"><feDropShadow dx="3" dy="3" stdDeviation="0" flood-color="'+accent+'"/></filter></defs><g id="Introduction" filter="url(#ink-shadow)">');
if(data.headingStyle==='outline')svg=svg.replace('<g id="Introduction">','<g id="Introduction" stroke="'+(data.ink||'#0b0b0b')+'" stroke-width="1">');
if(data.headingStyle==='label')svg=svg.replace('<g id="Introduction">','<g id="Introduction"><path d="M45 175 1110 164 1125 '+(195+headline.length*85)+' 50 '+(205+headline.length*85)+'Z" fill="'+accent+'" opacity=".22"/>');
if(data.edge)svg=svg.replaceAll('<rect x=','<rect rx="'+Math.max(0,Math.min(50,+data.edge))+'" x=');
if(data.texture==='dots'||data.texture==='paper'){const dots=Array.from({length:400},(_,i)=>'<circle cx="'+(i%40*30+10)+'" cy="'+(Math.floor(i/40)*50+120)+'" r="'+(data.texture==='dots'?2:.8)+'" fill="'+(data.ink||'#0b0b0b')+'" opacity=".15"/>').join('');svg=svg.replace('<g id="Header">','<g id="Texture">'+dots+'</g><g id="Header">')}
if(data.texture==='checker'&&root.fixxAssets)svg=svg.replace('<g id="Header">','<g id="Checker-strip" transform="translate(0 90) scale(12 .2)" style="color:'+(data.ink||'#0b0b0b')+'">'+root.fixxAssets.checker+'</g><g id="Header">');
if(root.fixxDecorations)svg=svg.replace('</svg>', '<g id="Editable-stickers">'+root.fixxDecorations(data.stickers||[],true)+'</g></svg>');
return svg;
}
root.makePortfolioVector=makePortfolioVector;if(typeof module!=='undefined')module.exports={makePortfolioVector};
})(typeof window!=='undefined'?window:globalThis);
