(function(root){
const shapes={
crown:'<path d="M18 83 8 24 39 48 54 12 72 47 94 26 86 85Z" fill="none" stroke="currentColor" stroke-width="6" stroke-linejoin="round"/><path d="M20 94 86 92" stroke="currentColor" stroke-width="5"/>',
bolt:'<path d="M55 5 15 57 43 55 30 96 88 34 57 38 73 8Z" fill="currentColor" stroke="#0b0b0b" stroke-width="3"/>',
spark:'<path d="M50 3C45 38 38 44 3 50c35 5 42 12 47 47 5-35 12-42 47-47C62 44 55 38 50 3Z" fill="currentColor"/>',
heart:'<path d="M50 89C32 71 5 54 10 28 14 6 42 10 50 30 61 6 89 9 93 30 97 54 68 76 50 89Z" fill="none" stroke="currentColor" stroke-width="6"/>',
arrow:'<path d="M9 80Q35 28 84 26M63 11 88 24 75 50" fill="none" stroke="currentColor" stroke-width="7" stroke-linecap="round" stroke-linejoin="round"/>',
paint:'<path d="m2 38 17-8-8-8 38 4 30-11-5 14 22-2-13 13 15 6-23 9 18 7-37 3-17 13-2-10-30 2 13-15-18-4Z" fill="currentColor"/>',
checker:Array.from({length:25},(_,i)=>`<rect x="${i%5*20}" y="${Math.floor(i/5)*20}" width="20" height="20" fill="${(i%5+Math.floor(i/5))%2?'#f3ebd6':'currentColor'}"/>`).join(''),
tape:'<path d="m5 28 90-8-6 12 8 9-7 9 5 16-91 9 7-14-8-12 7-10Z" fill="currentColor" opacity=".8"/><path d="m17 38 66-6M18 48l62-6M17 58l65-6" stroke="#f3ebd6" opacity=".3"/>',
rose:'<path d="M49 57 48 95M48 81Q15 84 13 63q25-2 35 18M49 73q29 0 37-22-28 0-37 22" fill="#55633a" stroke="#0b0b0b" stroke-width="3"/><path d="M47 7 63 14 76 12 83 29 78 42 63 57 43 61 24 48 16 32 25 18Z" fill="currentColor" stroke="#0b0b0b" stroke-width="4"/><path d="m32 21 22-2 15 12-10 15-20-2-9-13 15-7 13 7-8 9-9-7M24 40l19 14 22-9M62 15l12 23" fill="none" stroke="#0b0b0b" stroke-width="3"/>',
spray:'<path d="M34 25h33l9 66q-26 10-50 0Z" fill="#f3ebd6" stroke="#0b0b0b" stroke-width="4"/><path d="M37 12h26v13H37Z" fill="currentColor" stroke="#0b0b0b" stroke-width="4"/><path d="M45 4h14v8H45Z" fill="#0b0b0b"/><path d="m56 34-17 27h14l-9 24 23-33H54Z" fill="currentColor"/><path d="m20 7-12-3m13 11L5 16m16 7L8 29" stroke="currentColor" stroke-width="3"/>',
dots:Array.from({length:64},(_,i)=>`<circle cx="${i%8*12+7}" cy="${Math.floor(i/8)*12+7}" r="${1+i%4*.7}" fill="currentColor"/>`).join(''),
badge:'<path d="m50 3 10 12 16-1 2 16 15 7-8 14 6 15-16 5-5 16-16-4-13 10-10-13-16-1 1-16L3 53l11-12-3-16 16-3L35 7Z" fill="currentColor" stroke="#0b0b0b" stroke-width="3"/><text x="50" y="58" text-anchor="middle" font-family="Arial" font-weight="900" font-size="18" fill="#f3ebd6">CREATE</text>'};
function assetSvg(id,color='#c21f1f'){color=/^#[\da-f]{6}$/i.test(color)?color:'#c21f1f';return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" style="color:${color}" fill="none">${shapes[id]||shapes.spark}</svg>`}
function decorations(items=[],svgMode=false){return items.map((a,i)=>{const body=(shapes[a.kind]||shapes.spark).replaceAll('currentColor',/^#[\da-f]{6}$/i.test(a.color)?a.color:'#c21f1f');const x=Math.max(0,Math.min(90,+a.x||0)),y=Math.max(0,Math.min(80,+a.y||0)),size=Math.max(30,Math.min(220,+a.size||80)),rotate=+a.rotate||0;return svgMode?`<g id="Sticker-${i+1}-${a.kind}" transform="translate(${x*12} ${y*5}) rotate(${rotate} ${size/2} ${size/2}) scale(${size/100})">${body}</g>`:`<svg aria-hidden="true" viewBox="0 0 100 100" style="position:absolute;left:${x}%;top:${y}%;width:${size}px;height:${size}px;transform:rotate(${rotate}deg);pointer-events:none;opacity:.95" fill="none">${body}</svg>`}).join('')}
root.fixxAssets=shapes;root.assetSvg=assetSvg;root.fixxDecorations=decorations;if(typeof module!=='undefined')module.exports={shapes,assetSvg,decorations};
})(typeof window!=='undefined'?window:globalThis);

