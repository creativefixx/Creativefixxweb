CREATIVE FIXX — NINE PORTFOLIO COMPOSITIONS

Street Poster: A split cover, overlapping art wall, and torn-paper project labels.
The Design Journal: A magazine masthead, numbered chapters, and alternating case studies.
Sticker Scrapbook: A notebook sidebar with scattered polaroid cards and taped captions.
Type Manifesto: A giant type cover and a numbered project index with artwork reveals.
The Exhibition: A slim vertical identity rail beside an asymmetric image-first gallery.
The Slide Deck: A cover slide and horizontally scrolling, full-size project slides.
Soft Form Studio: A sculptural serif cover, curated image strip, and rounded brand-board sections.
Shape Playground: A geometric split cover, colorful project tiles, and a modular identity system.
The Editorial Grid: Condensed typography, vertical side labels, and a mixed-size publishing wall.

New inspirations: sculptural serif typography and spacious brand boards; bright outlined geometric identities; condensed editorial posters and modular publishing grids. These are original templates, not copies of reference logos or photos.

Live text and vector groups are editable. Fonts are not included; install the matching font or substitute your own. Soft Form Studio uses Cormorant Garamond as a freely available web-font interpretation of the sculptural serif direction.
