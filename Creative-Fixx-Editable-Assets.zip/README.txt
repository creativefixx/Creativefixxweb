21 ORIGINAL EDITABLE VECTOR MOTIFS

Street-style collection: crown, bolt, sparkle, heart, arrow, paint, checker, tape, rose, spray, dots, badge.
Soft Form collection: arch, oval, botanical.
Shape Playground collection: petal, orbit, wave.
Editorial Grid collection: bracket, label, cross.

Download individually or choose the matching template kit. All motifs are editable SVGs. Original motifs can be used in personal or commercial portfolios; reference logos, character artwork and photography are not part of this asset license.
